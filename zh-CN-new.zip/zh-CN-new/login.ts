export default {
    dengLu:  'login', 
    yanZhengMa:  'verify code', 
    qingShuRuYanZheng:  'please input verify code！', 
         dengLuZhangHao:  'login account', 
    houTaiGuanLiXi:  'backend management system', 
    mLShiChangBu:  'ML marketing', 
    qingXianDaKaiNin:  'please open your phone's google Authenticator app , scan QR code', 
};
