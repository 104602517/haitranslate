export default {
    qiDong:  'start', 
         shuRuShuRuShu:  'input number', 
    zuiHouCunKuanShi:  'Last deposit time', 
    zuiHouDengLuShi:  'last login time', 
              dangQianSheZhiTiao:  'Current setting conditions:', 
    chenMoHuiYuanShai:  'Silent member filter settings', 
    chenMoHuiYuan:  'silent member', 
};
