export default {
    quanBu:  'all', 
      tuPian: '图片',
      xieYi: '协议',
      fuYan: '附言',
};
