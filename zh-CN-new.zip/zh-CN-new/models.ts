export default {
      xuNiDaiLi: '虚拟代理',
      daiLiYuMingGuan: '代理域名管理',
      jiaoYiHaXiZhi: '交易哈希值',
      zhengZaiQieHuanZhu: '正在切换主题！',
      xuNiHuiYuan: '虚拟会员',
};
