export default {
    leiXing:  'type', 
      chongZhiEDuLei: '充值额度类型',
    zhiFuShangHuHao:  'payment merchant's number', 
      queRenShouKuanShi: '确认收款时间',
      queRenFuKuanShi: '确认付款时间',
      chongZhiFaQiShi: '充值发起时间',
};
