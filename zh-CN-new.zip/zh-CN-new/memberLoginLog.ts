export default {
    caoZuoXinXi:  'operating information', 
    liuLanQi:  'browser', 
    wangZhi:  'URL', 
    gangWei:  'position', 
    buMen:  'department', 
};
