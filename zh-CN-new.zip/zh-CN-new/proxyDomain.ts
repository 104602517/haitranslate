export default {
    chuangJianRen:  'creator', 
         sEOZhuanShu:  'special for SEO', 
    chongZhiZongRenShu:  'Total number of deposits', 
    zongZhuCeRenShu:  'total registrants', 
    yuMingDiZhi:  'domain name address', 
    yuMingBeiZhu:  'domain name remark', 
    yuMingLeiBie:  'domain name category', 
    yuMingLeiXing:  'domain name type', 
    kEYChengGong:  'success', 
    yuMing:  'domain name', 
};
